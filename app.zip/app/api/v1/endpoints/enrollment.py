import datetime

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.curd import trigger_achievements
from app.db.session import SessionLocal
from app.models import Course
from app.models.enrollment import Enrollment
from app.schemas.enrollment import EnrollmentCreate
from app.crud.enrollment import get_active_enrollment, create_enrollment

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.post("/enrollments")
def enroll(payload: EnrollmentCreate, db: Session = Depends(get_db)):
    existing = get_active_enrollment(db, payload.user_id, payload.course_id)

    if existing:
        raise HTTPException(400, "Already enrolled")

    return create_enrollment(db, payload.user_id, payload.course_id)


@router.post("/enrollments/{enrollment_id}/complete-lesson")
def complete_lesson(enrollment_id: int, db: Session = Depends(get_db)):
    
    enrollment = db.query(Enrollment).get(enrollment_id)
    course = db.query(Course).get(enrollment.course_id)

    enrollment.completed_lessons_count += 1

    if enrollment.completed_lessons_count >= course.total_lessons:
        enrollment.status = "completed"
        enrollment.completed_at = datetime.utcnow()

        trigger_achievements(db, enrollment.user_id, course.total_lessons)

    db.commit()
    return {"message": "Lesson completed"}