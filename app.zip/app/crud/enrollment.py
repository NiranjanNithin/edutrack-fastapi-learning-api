from sqlalchemy.orm import Session
from app.models.enrollment import Enrollment

def get_active_enrollment(db: Session, user_id: int, course_id: int):
    return db.query(Enrollment).filter_by(
        user_id=user_id,
        course_id=course_id,
        status="active"
    ).first()


def create_enrollment(db: Session, user_id: int, course_id: int):
    enrollment = Enrollment(user_id=user_id, course_id=course_id)
    db.add(enrollment)
    db.commit()
    db.refresh(enrollment)
    return enrollment