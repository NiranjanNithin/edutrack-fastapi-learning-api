from sqlmodel import Session, select
from .models import Enrollment, Course, Achievement,User
from datetime import datetime



def create_user(session: Session, name: str, email: str):
    user = User(name=name, email=email)

    session.add(user)
    session.commit()
    session.refresh(user)

    return user


def get_dashboard(session: Session, user_id: int):

    # ✅ get user
    user = session.get(User, user_id)

    if not user:
        raise Exception("User not found")

    # ✅ get active enrollments
    enrollments = session.exec(
        select(Enrollment).where(
            Enrollment.user_id == user_id,
            Enrollment.status == "active"
        )
    ).all()

    active_courses = []

    for e in enrollments:
        course = session.get(Course, e.course_id)

        progress = (e.completed_lessons_count / course.total_lessons) * 100

        active_courses.append({
            "course_id": course.id,
            "title": course.title,
            "progress": round(progress, 2)
        })

    # ✅ get achievements
    achievements = session.exec(
        select(Achievement).where(Achievement.user_id == user_id)
    ).all()

    achievement_list = [
        {"title": a.title} for a in achievements
    ]

    return {
        "user": {
            "id": user.id,
            "name": user.name,
            "email": user.email
        },
        "active_courses": active_courses,
        "achievements": achievement_list
    }


def enroll_user(session: Session, user_id: int, course_id: int):
    

    # ✅ check duplicate active enrollment
    existing = session.exec(
        select(Enrollment)
        .where(Enrollment.user_id == user_id)
        .where(Enrollment.course_id == course_id)
        .where(Enrollment.status == "active")
    ).first()

    if existing:
        raise Exception("User already enrolled in this course")

    # ✅ create enrollment
    enrollment = Enrollment(
        user_id=user_id,
        course_id=course_id
    )

    session.add(enrollment)
    session.commit()
    session.refresh(enrollment)

    return enrollment



def complete_lesson(session: Session, enrollment_id: int):
    
    # ✅ get enrollment
    enrollment = session.get(Enrollment, enrollment_id)

    if not enrollment:
        raise Exception("Enrollment not found")

    # ✅ already completed
    if enrollment.status == "completed":
        raise Exception("Course already completed")

    # ✅ increment lesson count
    enrollment.completed_lessons_count += 1

    # ✅ get course info
    course = session.get(Course, enrollment.course_id)

    # ✅ check completion
    if enrollment.completed_lessons_count >= course.total_lessons:
        enrollment.status = "completed"
        enrollment.completed_at = datetime.utcnow()

        # ✅ trigger achievements
        trigger_achievements(session, enrollment, course)

    session.add(enrollment)
    session.commit()
    session.refresh(enrollment)

    return enrollment


def trigger_achievements(session: Session, enrollment, course):

    # ✅ get completed courses for user
    completed_courses = session.exec(
        select(Enrollment).where(
            Enrollment.user_id == enrollment.user_id,
            Enrollment.status == "completed"
        )
    ).all()

    # ✅ First course → Fast Starter
    if len(completed_courses) == 1:
        session.add(Achievement(
            user_id=enrollment.user_id,
            title="Fast Starter"
        ))

    # ✅ Deep Diver → 10+ lessons
    if course.total_lessons >= 10:
        session.add(Achievement(
            user_id=enrollment.user_id,
            title="Deep Diver"
        ))


