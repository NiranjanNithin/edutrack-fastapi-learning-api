from sqlmodel import SQLModel, create_engine, Session

# SQLite database file
DATABASE_URL = "sqlite:///./edutrack.db"

# Create engine
engine = create_engine(DATABASE_URL, echo=True)


# ✅ Create tables function
def create_db():
    SQLModel.metadata.create_all(engine)


# ✅ DB session (used in APIs)
def get_session():
    with Session(engine) as session:
        yield session