
from fastapi import FastAPI
from sqlmodel import Session
from app.database import create_db, engine
from app.seed import seed_data
from app import models

from fastapi import Depends, HTTPException
from sqlmodel import Session
from app.database import get_session
from app.schemas import EnrollmentCreate,UserCreate
from app.curd import enroll_user,complete_lesson,get_dashboard,create_user


app = FastAPI()



# ✅ Run on startup
@app.on_event("startup")
def on_startup():
    create_db()
    
    
 # ✅ run seeding
    with Session(engine) as session:
        seed_data(session)



@app.get("/")
def home():
    return {"message": "EduTrack API running"}


@app.post("/users")
def create_user_api(
    data: UserCreate,
    session: Session = Depends(get_session)
):
    return create_user(session, data.name, data.email)



@app.post("/enrollments")
def create_enrollment(
    data: EnrollmentCreate,
    session: Session = Depends(get_session)
):
    try:
        return enroll_user(session, data.user_id, data.course_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    
    
@app.post("/enrollments/{enrollment_id}/complete-lesson")
def complete_lesson_api(
    enrollment_id: int,
    session: Session = Depends(get_session)
):
    try:
        return complete_lesson(session, enrollment_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    


@app.get("/users/{user_id}/dashboard")
def dashboard(
    user_id: int,
    session: Session = Depends(get_session)
):
    try:
        return get_dashboard(session, user_id)
    except Exception as e:
        raise HTTPException(status_code=404, detail=str(e))


