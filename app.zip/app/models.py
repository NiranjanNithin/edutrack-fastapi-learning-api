from sqlmodel import SQLModel, Field
from typing import Optional
from datetime import datetime


# ✅ USER TABLE (already done)
class User(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    email: str
    created_at: datetime = Field(default_factory=datetime.utcnow)


# ✅ COURSE TABLE
class Course(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    title: str
    description: str
    total_lessons: int


# ✅ ENROLLMENT TABLE (IMPORTANT)
class Enrollment(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)

    user_id: int = Field(foreign_key="user.id")
    course_id: int = Field(foreign_key="course.id")

    completed_lessons_count: int = 0
    status: str = "active"

    started_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None


# ✅ ACHIEVEMENT TABLE
class Achievement(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)

    user_id: int = Field(foreign_key="user.id")
    title: str

    unlocked_at: datetime = Field(default_factory=datetime.utcnow)