from sqlmodel import SQLModel

class EnrollmentCreate(SQLModel):
    user_id: int
    course_id: int
    

class UserCreate(SQLModel):
    name: str
    email: str
