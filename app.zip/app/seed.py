from sqlmodel import Session, select
from .models import Course


def seed_data(session: Session):

    # ✅ check if already seeded
    existing_courses = session.exec(select(Course)).first()

    if existing_courses:
        return  # already added, avoid duplicates

    # ✅ create courses
    courses = [
        Course(
            title="Python Basics",
            description="Learn Python fundamentals",
            total_lessons=5
        ),
        Course(
            title="Intro to FastAPI",
            description="FastAPI beginner course",
            total_lessons=3
        ),
        Course(
            title="SQL 101",
            description="Learn SQL from scratch",
            total_lessons=10
        ),
    ]

    # ✅ insert into DB
    for course in courses:
        session.add(course)

    session.commit()